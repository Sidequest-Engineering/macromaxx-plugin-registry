import { exactKeys } from './contracts.js';

const isSlot = value => Number.isInteger(value) && value >= 0 && value < 128;
const isText = (value, max) => typeof value === 'string' && value.length > 0 &&
  value.length <= max * 2 && [...value].length <= max &&
  !/[\p{Cc}\p{Bidi_Control}\p{Surrogate}]/u.test(value);
const actionId = /^[a-z][a-z0-9-]{0,47}$/;
const sessionStates = new Set([
  'question', 'permission', 'retry', 'running', 'idle', 'succeeded', 'failed', 'interrupted', 'unknown',
]);

export function validateDeckLayout(layout) {
  exactKeys(layout, ['slots', 'backIndex']);
  if (!Array.isArray(layout.slots) || layout.slots.length < 5 || layout.slots.length > 128)
    throw new Error('Invalid deck slots.');
  const indices = new Set(), positions = new Set();
  for (const slot of layout.slots) {
    exactKeys(slot, ['index', 'row', 'column']);
    if (![slot.index, slot.row, slot.column].every(isSlot)) throw new Error('Invalid deck slot.');
    const position = `${slot.row}:${slot.column}`;
    if (indices.has(slot.index) || positions.has(position)) throw new Error('Duplicate deck slot.');
    indices.add(slot.index);
    positions.add(position);
  }
  if (!indices.has(layout.backIndex)) throw new Error('Invalid deck Back slot.');
  return layout;
}

export function validateDeckFrame(frame, layout) {
  exactKeys(frame, ['keys', 'animate', 'watch'], ['keys']);
  if (!Array.isArray(frame.keys) || frame.keys.length > 128 ||
    (Object.hasOwn(frame, 'animate') && typeof frame.animate !== 'boolean') ||
    (Object.hasOwn(frame, 'watch') && frame.watch !== 'opencode')) throw new Error('Invalid deck frame.');
  const assigned = new Set();
  const available = layout && new Set(validateDeckLayout(layout).slots.map(slot => slot.index));
  for (const key of frame.keys) {
    exactKeys(key, ['slot', 'title', 'subtitle', 'color', 'icon', 'action'], ['slot', 'title', 'color']);
    if (!isSlot(key.slot) || assigned.has(key.slot) ||
      (available && (!available.has(key.slot) || key.slot === layout.backIndex)))
      throw new Error('Invalid deck frame slot.');
    if (!isText(key.title, 32) || (Object.hasOwn(key, 'subtitle') && !isText(key.subtitle, 32)) ||
      typeof key.color !== 'string' || !/^#[0-9a-f]{6}$/i.test(key.color) ||
      (Object.hasOwn(key, 'icon') && key.icon !== 'spinner') ||
      (Object.hasOwn(key, 'action') && (typeof key.action !== 'string' || !actionId.test(key.action))))
      throw new Error('Invalid deck key.');
    assigned.add(key.slot);
  }
  return frame;
}

export function validateOpenCodeSnapshot(snapshot) {
  exactKeys(snapshot, ['connection', 'active', 'recent', 'activeTruncated']);
  if (!['loading', 'ready', 'offline', 'error'].includes(snapshot.connection) ||
    !Array.isArray(snapshot.active) || snapshot.active.length > 128 ||
    !Array.isArray(snapshot.recent) || snapshot.recent.length > 50 ||
    typeof snapshot.activeTruncated !== 'boolean' ||
    (snapshot.connection !== 'ready' && (snapshot.active.length || snapshot.recent.length)))
    throw new Error('Invalid OpenCode snapshot.');
  const ids = new Set();
  for (const row of [...snapshot.active, ...snapshot.recent]) {
    exactKeys(row, ['id', 'title', 'updatedAt', 'status']);
    if (typeof row.id !== 'string' || !/^ses[A-Za-z0-9_-]{1,125}$/.test(row.id) || ids.has(row.id) ||
      !isText(row.title, 80) || !Number.isFinite(row.updatedAt) || row.updatedAt < 0 ||
      !sessionStates.has(row.status)) throw new Error('Invalid OpenCode session row.');
    ids.add(row.id);
  }
  return snapshot;
}
