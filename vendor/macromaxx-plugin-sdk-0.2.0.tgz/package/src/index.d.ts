export type Permission = 'display:write' | 'settings:read' | 'settings:write' | 'deck:write' | 'opencode:sessions:read';
export type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
export interface Manifest {
  schemaVersion: 1;
  apiVersion: 1;
  runtime: 'standard';
  id: string;
  publisher: string;
  name: string;
  description: string;
  version: string;
  appVersion: string;
  platforms: Array<'linux' | 'win32' | 'darwin'>;
  permissions: Permission[];
  actions: Array<{
    id: string;
    name: string;
    fields?: Array<{ key: string; label: string; default?: string }>;
  }>;
}
export interface Display {
  label?: string;
  color?: string;
}
export interface ActionEvent {
  actionId: string;
  config: Record<string, Json>;
  keyId: string;
  long: boolean;
  deck?: DeckLayout;
}
export interface DeckLayout {
  slots: Array<{ index: number; row: number; column: number }>;
  backIndex: number;
}
export interface DeckFrame {
  keys: Array<{ slot: number; title: string; subtitle?: string; color: string; icon?: 'spinner'; action?: string }>;
  animate?: boolean;
  watch?: 'opencode';
}
export interface DeckEvent extends ActionEvent {
  deck: DeckLayout;
  keyAction?: string;
}
export type SessionStatus =
  | 'question' | 'permission' | 'retry' | 'running' | 'idle'
  | 'succeeded' | 'failed' | 'interrupted' | 'unknown';
export interface SessionRow {
  id: string;
  title: string;
  updatedAt: number;
  status: SessionStatus;
}
export interface OpenCodeSnapshot {
  connection: 'loading' | 'ready' | 'offline' | 'error';
  active: SessionRow[];
  recent: SessionRow[];
  activeTruncated: boolean;
}
export interface PluginAPI {
  readonly protocolVersion: 1;
  readonly platform: 'linux' | 'darwin' | 'win32';
  readonly permissions: readonly Permission[];
  display: { set(display: Display): void };
  deck: { open(frame: DeckFrame): void; set(frame: Omit<DeckFrame, 'watch'>): void };
  opencode: { sessions(): OpenCodeSnapshot };
  settings: { get(): Record<string, Json>; set(value: Record<string, Json>): void };
  log(message: string): void;
}
export type Handler = (event: ActionEvent, api: PluginAPI) => void | Promise<void>;
export interface PluginDefinition {
  activate?(api: PluginAPI): void | Promise<void>;
  deactivate?(api: PluginAPI): void | Promise<void>;
  actions: Record<string, {
    execute: Handler;
    keyDown?: Handler;
    keyUp?: Handler;
    deckRender?: (event: DeckEvent, api: PluginAPI) => void | Promise<void>;
  }>;
}
export declare function definePlugin<T extends PluginDefinition>(plugin: T): T;
