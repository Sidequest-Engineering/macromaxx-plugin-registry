#!/usr/bin/env node
import path from 'node:path';
import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { buildPlugin } from './build.js';
import { decodePackage } from './contracts.js';
try {
  const [command, argument] = process.argv.slice(2);
  if (command === 'build') {
    const output = path.resolve(argument || 'dist/plugin.mmxp');
    const bytes = await buildPlugin(process.cwd(), output);
    console.log(`${createHash('sha256').update(bytes).digest('hex')}  ${output}`);
  } else if (command === 'validate') {
    console.log(JSON.stringify(decodePackage(await fs.readFile(argument)).manifest, null, 2));
  } else throw new Error('Usage: macromaxx-plugin build [output.mmxp] | validate <package.mmxp>');
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
