// Deliberately portable: this entry point is bundled into the guest, never Node APIs.
export function definePlugin(plugin) {
  return plugin;
}
