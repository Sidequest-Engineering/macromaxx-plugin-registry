import fs from 'node:fs/promises';
import path from 'node:path';
import { build } from 'esbuild';
import { encodePackage, validateManifest } from './contracts.js';

export async function buildPlugin(directory, output) {
  const manifest = validateManifest(
    JSON.parse(await fs.readFile(path.join(directory, 'manifest.json'), 'utf8')),
  );
  const result = await build({
    entryPoints: [path.join(directory, 'src/index.ts')],
    bundle: true,
    write: false,
    format: 'iife',
    globalName: '__pluginModule',
    platform: 'browser',
    target: 'es2020',
    sourcemap: false,
    legalComments: 'none',
    charset: 'utf8',
  });
  const bytes = encodePackage(manifest, result.outputFiles[0].text);
  await fs.mkdir(path.dirname(output), { recursive: true });
  await fs.writeFile(output, bytes, { flag: 'wx' });
  return bytes;
}
