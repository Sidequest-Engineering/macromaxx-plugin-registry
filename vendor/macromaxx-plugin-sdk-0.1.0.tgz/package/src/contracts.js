import semver from 'semver';

export const MAX_PACKAGE_BYTES = 2 * 1024 * 1024;
export const MAX_CODE_BYTES = 1024 * 1024;
export const MAX_SETTINGS_BYTES = 64 * 1024;
export const PERMISSIONS = Object.freeze(['display:write', 'settings:read', 'settings:write']);
const token = /^[a-z][a-z0-9-]{0,47}$/;
const fail = (message) => {
  throw new Error(message);
};
const object = (value) => value && typeof value === 'object' && !Array.isArray(value);
const text = (value, max) =>
  typeof value === 'string' &&
  value.length > 0 &&
  value.length <= max &&
  !/[\u0000-\u001f]/.test(value);
export function exactKeys(value, allowed, required = allowed) {
  if (
    !object(value) ||
    Object.keys(value).some((key) => !allowed.includes(key)) ||
    required.some((key) => !Object.hasOwn(value, key))
  )
    fail('Unknown or missing fields.');
}

export function validateManifest(value) {
  exactKeys(value, [
    'schemaVersion',
    'id',
    'publisher',
    'name',
    'description',
    'version',
    'apiVersion',
    'appVersion',
    'runtime',
    'platforms',
    'permissions',
    'actions',
  ]);
  if (value.schemaVersion !== 1 || value.apiVersion !== 1 || value.runtime !== 'standard')
    fail('Unsupported plugin schema, API or runtime.');
  if (
    !token.test(value.publisher) ||
    typeof value.id !== 'string' ||
    !value.id.startsWith(value.publisher + '--') ||
    !token.test(value.id.slice(value.publisher.length + 2))
  )
    fail('Invalid publisher/plugin ID.');
  if (
    !text(value.name, 80) ||
    !text(value.description, 500) ||
    !semver.valid(value.version) ||
    semver.prerelease(value.version)
  )
    fail('Invalid name, description or stable version.');
  if (
    !text(value.appVersion, 100) ||
    !semver.validRange(value.appVersion) ||
    semver.validRange(value.appVersion) === '*'
  )
    fail('Explicit compatible app version range required.');
  if (
    !Array.isArray(value.platforms) ||
    !value.platforms.length ||
    new Set(value.platforms).size !== value.platforms.length ||
    value.platforms.some((p) => !['linux', 'win32', 'darwin'].includes(p))
  )
    fail('Invalid platforms.');
  if (
    !Array.isArray(value.permissions) ||
    new Set(value.permissions).size !== value.permissions.length ||
    value.permissions.some((p) => !PERMISSIONS.includes(p))
  )
    fail('Unsupported permissions.');
  if (
    !Array.isArray(value.actions) ||
    !value.actions.length ||
    value.actions.length > 32 ||
    new Set(value.actions.map((a) => a?.id)).size !== value.actions.length
  )
    fail('Invalid actions.');
  for (const action of value.actions) {
    exactKeys(action, ['id', 'name', 'fields'], ['id', 'name']);
    if (!token.test(action.id) || !text(action.name, 80)) fail('Invalid action ID/name.');
    if (action.fields !== undefined) {
      if (
        !Array.isArray(action.fields) ||
        action.fields.length > 32 ||
        new Set(action.fields.map((f) => f?.key)).size !== action.fields.length
      )
        fail('Invalid fields.');
      for (const field of action.fields) {
        exactKeys(field, ['key', 'label', 'default'], ['key', 'label']);
        if (
          !/^[a-zA-Z][a-zA-Z0-9_]{0,47}$/.test(field.key) ||
          !text(field.label, 80) ||
          (field.default !== undefined &&
            (typeof field.default !== 'string' || field.default.length > 4096))
        )
          fail('Invalid configuration field.');
      }
    }
  }
  return JSON.parse(JSON.stringify(value));
}

export function jsonValue(value, maxBytes = MAX_SETTINGS_BYTES) {
  const json = JSON.stringify(value);
  if (json === undefined || Buffer.byteLength(json) > maxBytes) fail('JSON value exceeds quota.');
  const parsed = JSON.parse(json);
  function visit(v, depth = 0) {
    if (depth > 20) fail('JSON nesting exceeds quota.');
    if (v && typeof v === 'object')
      for (const [key, child] of Object.entries(v)) {
        if (['__proto__', 'prototype', 'constructor'].includes(key)) fail('Unsafe JSON key.');
        visit(child, depth + 1);
      }
  }
  visit(parsed);
  return parsed;
}

export function encodePackage(manifest, code) {
  const pkg = { format: 'macromaxx-plugin/1', manifest: validateManifest(manifest), code };
  if (typeof code !== 'string' || !code.trim() || Buffer.byteLength(code) > MAX_CODE_BYTES)
    fail('Invalid plugin code size.');
  const bytes = Buffer.from(JSON.stringify(pkg));
  if (bytes.length > MAX_PACKAGE_BYTES) fail('Package exceeds quota.');
  return bytes;
}

export function decodePackage(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength > MAX_PACKAGE_BYTES)
    fail('Package exceeds quota.');
  const pkg = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  exactKeys(pkg, ['format', 'manifest', 'code']);
  if (pkg.format !== 'macromaxx-plugin/1') fail('Unsupported package format.');
  encodePackage(pkg.manifest, pkg.code);
  return { ...pkg, manifest: validateManifest(pkg.manifest) };
}

export function validateCatalog(value) {
  exactKeys(value, ['schemaVersion', 'expires', 'releases']);
  if (
    value.schemaVersion !== 1 ||
    typeof value.expires !== 'string' ||
    !Number.isFinite(Date.parse(value.expires)) ||
    !Array.isArray(value.releases) ||
    value.releases.length > 10000
  )
    fail('Invalid catalog.');
  const identities = new Set();
  for (const release of value.releases) {
    exactKeys(release, ['manifest', 'sha256', 'length', 'status']);
    validateManifest(release.manifest);
    const key = release.manifest.id + '@' + release.manifest.version;
    if (identities.has(key)) fail('Duplicate release.');
    identities.add(key);
    if (
      !/^[a-f0-9]{64}$/.test(release.sha256) ||
      !Number.isSafeInteger(release.length) ||
      release.length < 1 ||
      release.length > MAX_PACKAGE_BYTES ||
      !['approved', 'withdrawn', 'revoked'].includes(release.status)
    )
      fail('Invalid release.');
  }
  return JSON.parse(JSON.stringify(value));
}
