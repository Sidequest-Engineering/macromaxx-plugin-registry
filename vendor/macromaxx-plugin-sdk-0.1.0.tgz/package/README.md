# MacroMaxx Plugin SDK v0.1

Portable JavaScript/TypeScript plugins for protocol **1**. No Node, DOM, network, filesystem, terminal or native-addon APIs are available. This is not Elgato's SDK.

Start with `../macromaxx-plugin-example`. Its `src/index.ts` exports `definePlugin({ actions: ... })`. `manifest.json` declares a publisher-namespaced ID, stable version, compatible app range, supported platforms, action IDs and explicit permissions. Runtime validation rejects unsupported fields/permissions; the JSON Schema is an editor aid, not a replacement for runtime validation.

## Development

```sh
npm ci --ignore-scripts
npm test
```

In a plugin project with the SDK installed:

```sh
macromaxx-plugin build dist/plugin-1.0.0.mmxp
macromaxx-plugin validate dist/plugin-1.0.0.mmxp
```

The build accepts `src/index.ts` (including ordinary JS syntax), bundles dependencies for a browser-compatible ES2020 environment and emits an IIFE. It does not allow unresolved Node builtins. Run your own dependency installation/builds only in your development environment, never in the client installer. Build output uses create-only writes; use a new output path or deliberately remove your own old development output. Identical inputs/toolchain yield identical bundle bytes; this is not a guarantee across dependency/compiler versions. Commit lockfiles.

## API

```ts
import { definePlugin } from '@macromaxx/plugin-sdk';
export default definePlugin({
  actions: {
    hello: {
      execute(event, api) {
        api.display.set({ label: String(event.config.name || 'Hello') });
      }
    }
  }
});
```

- `activate(api)` runs before use. The low-level runtime can dispatch `deactivate(api)`, but the current store **force-stops on ordinary disable/uninstall as well as shutdown/cancellation/revocation** and does not invoke this optional hook. Do not rely on it for cleanup. Graceful store deactivation is deferred; there are no guest-owned OS resources in v1.
- `actions[id].execute(event, api)`: required for each manifest action. Async handlers may use guest promises, not host timers/I/O.
- `keyDown`, `keyUp`: optional; physical events go to the first assigned short-press action. `execute` follows existing app chain/long-press semantics, so keyDown/keyUp are **not** an additional execute callback.
- `event`: actionId, assigned keyId, action-local JSON config and `long` flag. Never an entire workspace.
- `api.display.set({label?,color?})`: transient patch for the invoking key, label max 80 chars, color `#rrggbb`; requires `display:write`.
- `api.settings.get()/set(object)`: plugin-local non-secret JSON, max 64 KiB, depth 20; requires `settings:read`/`settings:write`. `set` replaces the settings object. Stored unencrypted, excluded from workspace exports, removed by uninstall.
- `api.log(message)`: max 20 messages of 1000 chars per event.
- `api.permissions`, `api.platform`, `api.protocolVersion`: read-only guest information. Security is enforced again outside the guest; changing guest globals never grants rights.

Guest heap is limited to 16 MiB, stack to 256 KiB, event execution to ~2 seconds with an independent 5-second supervisor deadline. One process/context is retained per active plugin; settings, not module globals, survive process restarts. Processes start lazily; an install activation probe ensures basic loadability, not correctness or harmlessness.

## Package and compatibility

`.mmxp` is UTF-8 JSON containing exactly `format`, `manifest`, `code`. There is **no ZIP/tar extraction**, arbitrary file map, symlink support, native payload or install script. Package max 2 MiB, code max 1 MiB. Runtime and schema APIs are version 1; npm package version is independently 0.1.0. Unsupported protocol versions fail closed. A breaking protocol needs a new runtime adapter rather than an implicit reinterpretation of old plugins.

Legacy `execute(config, context)` Node plugins are a different, privileged local trust model and are not accepted as standard store packages. Port portable logic, replace filesystem/network access with supported APIs (not available in v1), and namespace the new ID rather than relabeling old code as sandboxed.
